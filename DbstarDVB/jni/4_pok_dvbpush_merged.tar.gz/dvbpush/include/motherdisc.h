﻿#ifndef __MOTHERDISC_H__
#define __MOTHERDISC_H__

int receive_status_get();
int motherdisc_processing();
int motherdisc_parse();
int motherdisc_process();

#endif
