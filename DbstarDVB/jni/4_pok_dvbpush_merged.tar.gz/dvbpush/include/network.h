#ifndef __NETWORK_H__
#define __NETWORK_H__

int network_getinfo(char *buf, unsigned int len);

#endif
