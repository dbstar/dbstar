//ȫ��ʹ�õ�ͷ�ļ����������������ļ���������

#ifndef __COMMON_H__
#define __COMMON_H__
#include <errno.h>

extern int debug_level_get(void);

// �����tuner�źŰ汾������˺ꣻ����������汾
#define TUNER_INPUT

#define DVBPUSH_DEBUG_ANDROID 1
#if DVBPUSH_DEBUG_ANDROID
#include <android/log.h>
#define LOG_TAG "dvbpush"

#define PRINTF(x...) do{__android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, x);} while(0)

#define DEBUG(x...) do { \
	__android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, "[%s:%d] ", __FUNCTION__, __LINE__); \
	__android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, x); \
} while(0)

#define ERROROUT(x...) do { \
	__android_log_print(ANDROID_LOG_ERROR, LOG_TAG, "[%s:%s:%d] ", __FILE__, __FUNCTION__, __LINE__); \
	if (errno != 0) \
		__android_log_print(ANDROID_LOG_ERROR, LOG_TAG, "[err note: %s]",strerror(errno)); \
	__android_log_print(ANDROID_LOG_ERROR, LOG_TAG, x); \
} while(0)

#else

#define PRINTF(x...) do{printf(x);} while(0)

#define DEBUG(x...) do{printf("[%s:%s:%d] ", __FILE__, __FUNCTION__, __LINE__);printf(x);}while(0)

#define ERROROUT(ERRSTR...) \
			do{printf("[%s:%s:%d] ", __FILE__, __FUNCTION__, __LINE__);\
			if(errno!=0) printf("[err note: %s]",strerror(errno));\
			printf(ERRSTR);}while(0)
#endif

#define MIN_LOCAL(a,b) ((a)>(b)?(b):(a))

typedef enum{
	BOOL_FALSE = 0,
	BOOL_TRUE
}BOOL_E;

/*
 �ж˰汾�ţ����Ǵ�loader��ȡ�ģ����Ǹ��ݹ�����Ҫ����ģ�ÿ�η����汾��Ҫ�ֹ�����
*/
#define HARDWARE_VERSION	"06.01"
#define LOADER_VERSION		"1.0.1"


// �����DRM��֤�汾������˺�
//#define DRM_TEST

// ������Ŀ
//#define SMARTLIFE_LC

// ������Ŀ����ý�����
#define MEDIASHARING_LC

// ������Ŀ���ļ����
#define FILEBROWSER_LC

// ������Ŀ���ҵ�Ӧ��
#define MYAPP_LC

// ������Ŀ�������
#define WEBBROWSER_LC

// ������Ŀ��CNTV
#define CNTV_LC

/*
��������ʹ�õ����á�fifo�ļ���
*/
#define	WORKING_DATA_DIR	"/data/dbstar"
#define	MSG_FIFO_ROOT_DIR	WORKING_DATA_DIR"/msg_fifo"
#define SETTING_BASE		WORKING_DATA_DIR"/dbstar.conf"
#define PUSH_CONF			"/system/etc/dbstar/push.conf"
#define INITIALIZE_XML_URI	"pushroot/initialize/Initialize.xml"
#define MOTHERDISC_XML_URI	"ContentDelivery.xml"

/*
�������й����в��������ݣ����������ص�ƬԴ����Ӧ�����ݿ�
*/
#define PUSH_DATA_DIR_DF	"/storage/external_storage/sda1"	// �ο�push.conf��DATA_DIR���弰ʱˢ�£��Ա�Ӧ��ʹ��
#define DBSTAR_DATABASE			WORKING_DATA_DIR"/Dbstar.db"
#define SMARTHOME_DATABASE		WORKING_DATA_DIR"/Smarthome.db"

// �״ο���Launcher��Ҫ���������ʼ������ʼ����Ϻ�Launcherд��˱���ļ���Ŀǰ���ݽ�һ���ַ���1��
#define NETWORK_INIT_FLAG		"/data/data/com.dbstar/files/flag"
#define DEVICE_NUM_CHANGED_FLAG	"/cache/recovery/last_log"

#define	SERVICE_ID			"01"
#define ROOT_CHANNEL		(400)	// 0x190
#define PROG_DATA_PID_DF	(411)	// 0x19b
#define ROOT_PUSH_FILE		"Initialize.xml"
#define ROOT_PUSH_FILE_SIZE	(1024)			/* Is this len right??? */
#define MULTI_BUF_SIZE	(16171008)	/* (16171008)=(12*1024*1316) */
//#define MULTI_BUF_SIZE		(86245376)	/* (86245376)=(64*1024*1316) ~ 79M */
//#define MULTI_BUF_SIZE		(43122688)	/* (43122688)=(32*1024*1316) ~ 41M */

#define SERVICEID_FILL		"0"
#define XML_ROOT_ELEMENT	"RootElement"
#define EXTENSION_STR_FILL	"Extension"
#define OBJID_PAUSE			"_|_"
#define OBJ_SERVICE			"Service"
#define OBJ_PRODUCT			"Product"
#define OBJ_PUBLICATIONSSET	"PublicationsSet"
#define OBJ_PUBLICATION		"Publication"
#define OBJ_MFILE			"MFile"
#define OBJ_COLUMN			"Column"
#define OBJ_GUIDELIST		"GuideList"
#define OBJ_PRODUCTDESC		"ProductDesc"
#define OBJ_MESSAGE			"Message"
#define OBJ_PREVIEW			"Preview"

#define GLB_NAME_SERVICEID			"serviceID"
#define GLB_NAME_PUSHDIR			"PushDir"
#define GLB_NAME_COLUMNRES			"ColumnRes"
#define GLB_NAME_PREVIEWPATH		"PreviewPath"
#define GLB_NAME_CURLANGUAGE		"CurLanguage"
#define GLB_NAME_OPERATIONBUSINESS	"OperationBusiness"
#define GLB_NAME_SMARTCARDID		"SmartCardID"
#define GLB_NAME_ORDERPRODUCT		"OrderProduct"
#define GLB_NAME_DATASOURCE			"PushSource"
#define GLB_NAME_HDFOREWARNING		"HDForeWarning"
#define GLB_NAME_PRODUCTSN			"ProductSN"
#define GLB_NAME_DEVICEMODEL		"DeviceModel"
#define GLB_NAME_HARDWARE_VERSION	"HardwareVersion"
#define GLB_NAME_SOFTWARE_VERSION	"SoftwareVersion"
#define GLB_NAME_LOADER_VERSION		"LoaderVersion"
#define GLB_NAME_DBDATASERVERIP		"DBDataServerIP"
#define GLB_NAME_DBDATASERVERPORT	"DBDataServerPort"
#define GLB_NAME_REBOOT_TIMESTAMP	"RebootStamp"

#define INITIALIZE_MIDPATH	"pushroot/initialize"
#define DBSTAR_PREVIEWPATH	"/mnt/sda1/dbstar/PreView"
#define COLUMN_RES			WORKING_DATA_DIR"/ColumnRes"

#define LOCAL_COLUMNICON_ORIGIN_DIR	"/system/etc/dbstar/ColumnRes/LocalColumnIcon"

#define CURLANGUAGE_DFT				"cho"
#define DEVICEMODEL_DFT				"01"
#define DBDATASERVERIP_DFT			"239.1.7.5"
#define DBDATASERVERPORT_DFT		"4321"

// ����Ӧ�ø��������������㹻�ռ��⣬����Ԥ��20G
#define HDFOREWARNING_M_DFT			(102400LL)
// ���������������㹻�ռ��⣬����32G
#define DOWNLOAD_ONCE_M_MIN			(32768LL)

typedef enum{
	NAVIGATIONTYPE_NOCOLUMN = 0,
	NAVIGATIONTYPE_COLUMN
}NAVIGATIONTYPE_E;

/*
Ĭ�ϵĳ�ʼ���ļ�uri�������push��·����uri��������Initialize.xml��Channel.xml��·��
�������й����п��ܻᱻ����
*/
typedef enum{
	PUSH_XML_FLAG_UNDEFINED	= -1,
	PUBLICATION_DIR			= 0,
	
	INITIALIZE_XML			= 100,
	COLUMN_XML				= 101,
	GUIDELIST_XML			= 102,
	COMMANDS_XML			= 104,
	MESSAGE_XML				= 105,
	PRODUCTDESC_XML			= 106,
	SERVICE_XML				= 107,
	SPRODUCT_XML			= 108,
	
// defined myself
	PUBLICATION_XML			= 10000,
	
	
	PUSH_XML_FLAG_MAXLINE
}PUSH_XML_FLAG_E;


/*
	���ֵܽڵ��У�ֻ��Ҫ�������ڵ��ڲ���Ϣ����Ϻ���Ҫ����ɨ�������ֵܽڵ㣬����process_overΪ1��
	�������������д����ж��������Ϸ�ʱ�ݹ�parseNode�����ڲ����ڲ�������Ϻ������ڵ������
	1���Ѿ��ҵ��Ϸ��ķ�֧��ʣ�µķ�֧�����������ǰ�˳�
	2����ҵ���߼����жϲ���Ҫ���������磬ServiceID��ƥ�䣬���߰汾���
	3��������������ǰ�˳�
*/
typedef enum{
	XML_EXIT_NORMALLY = 0,
	XML_EXIT_MOVEUP = 1,
	XML_EXIT_UNNECESSARY = 2,
	XML_EXIT_ERROR = 3,
}XML_EXIT_E;


/*
	����֧�ֶ�ҵ������Ҫ���Ƿ�ע����յ��ն˶��ԣ���Ҫ��¼ҵ���״̬��
	0������ҵ����Ч
	1������ҵ�����ն���Ҫ֧�ֵ�ҵ��֮һ�������ǵ�ǰ��Ч��ҵ��ֻ���ڶ�ҵ��֧��ʱ������Ҫ��ֵ��
	2������ҵ�����ն˵ĵ�ǰ��Чҵ��
*/
typedef enum{
	SERVICE_STATUS_INVALID	= 0,
	SERVICE_STATUS_VALID	= 1,
	SERVICE_STATUS_EFFECT	= 2
}SERVICE_STATUS_E;


/*
	����Ͷ�ݵ��еĽ�Ŀ����
*/
typedef enum{
	RECEIVETYPE_PUBLICATION	= 0,
	RECEIVETYPE_SPRODUCT	= 1,
	RECEIVETYPE_COLUMN		= 2,
	RECEIVETYPE_PREVIEW		= 3
}RECEIVETYPE_E;

/*
	����״̬
*/
typedef enum{
	RECEIVESTATUS_REJECT		= -2,
	RECEIVESTATUS_FAILED		= -1,
	RECEIVESTATUS_WAITING		= 0,
	RECEIVESTATUS_FINISH		= 1,
	RECEIVESTATUS_HISTORY		= 2,
	RECEIVESTATUS_REJECT_TMP	= 3
}RECEIVESTATUS_E;

/*
 dvbpush��ʼ������������
*/
typedef enum{
	RELY_CONDITION_NET = 1,
	RELY_CONDITION_HD = 2,
	RELY_CONDITION_UPGRADE = 4,
	
	RELY_CONDITION_EXIT = 128
}RELY_CONDITION_E;


/*
��Ʒ�Ʒ���Ӫ����
*/
typedef enum{
	PRODUCTTYPE_INVALID = 0,
	PRODUCTTYPE_VOD = 1,				// �㲥��Ʒ
	PRODUCTTYPE_WHOLESALE_BY_MON = 2,	// ���²�Ʒ
	PRODUCTTYPE_PACKAGE = 3,			// ר���Ʒ
	PRODUCTTYPE_SPECIAL = 4				// �����Ʒ
}PRODUCTTYPE_E;


/*
��Ʒ����
*/
typedef enum{
	PRODUCTFLAG_INVALID = 0,
	PRODUCTFLAG_NORMAL = 1,		// ��ͨ��Ʒ����Ʒ��
	PRODUCTFLAG_PREVIEW = 2,	// СƬ��Ʒ
	PRODUCTFLAG_SPRODUCT = 3	// �����Ʒ
}PRODUCTFLAG_E;


/*
���ز���pushʱʹ�ã����hytd.ts������������������¹رմ˺ꡣ
*/
//#define LOCAL_PUSH_TEST

typedef struct{
	char	Name[64];
	char	Value[512];
	char	Param[256];
}DBSTAR_GLOBAL_S;

typedef struct{
	char	productID[64];
	char	productName[64];
	char	serviceID[64];
}DBSTAR_PRODUCT_SERVICE_S;

typedef struct{
	char	PushFlag[64];
	char	ServiceID[64];
	char	XMLName[64];
	char	Version[64];
	char	StandardVersion[64];
	char	URI[256];
	char	ID[64];
}DBSTAR_XMLINFO_S;

typedef struct{
	char	ServiceID[64];
	char	pid[64];
	char	pidtype[64];
	char	multiURI[64];
}DBSTAR_CHANNEL_S;

typedef struct{
	char	ServiceID[64];
	char	ObjectName[128];
	char	EntityID[64];
	char	StrLang[32];
	char	StrName[64];
	char	StrValue[8192];
	char	Extension[64];	// "Extension" or ""
}DBSTAR_RESSTR_S;

typedef struct{
	char	ServiceID[64];
	char	ObjectName[64];
	char	EntityID[64];
	char	SubTitleID[64];
	char	SubTitleName[64];
	char	SubTitleLanguage[64];
	char	SubTitleURI[256];
}DBSTAR_RESSUBTITLE_S;

typedef struct{
	char	ServiceID[64];
	char	ObjectName[64];
	char	EntityID[64];
	char	TrailerID[64];
	char	TrailerName[64];
	char	TrailerURI[256];
}DBSTAR_RESTRAILER_S;

typedef struct{
	char	ServiceID[64];
	char	ObjectName[64];
	char	EntityID[64];
	char	PosterID[64];
	char	PosterName[64];
	char	PosterURI[256];
}DBSTAR_RESPOSTER_S;

typedef struct{
	char	ServiceID[64];
	char	ObjectName[64];
	char	EntityID[64];
	char	Name[64];
	char	Type[64];
}DBSTAR_RESEXTENSION_S;

typedef struct{
	char	ServiceID[64];
	char	ObjectName[256];
	char	EntityID[64];
	char	FileID[64];
	char	FileName[64];
	char	FileURI[256];
}DBSTAR_RESEXTENSIONFILE_S;

typedef struct{
	char	ServiceID[64];
	char	RegionCode[64];
	char	OnlineTime[32];
	char	OfflineTime[32];
	char	Status[32];
}DBSTAR_SERVICE_S;

typedef struct{
	char	ServiceID[64];
	char	ProductID[64];
	char	ProductType[64];
	char	Flag[64];
	char	OnlineDate[64];
	char	OfflineDate[64];
	char	IsReserved[64];
	char	Price[64];
	char	CurrencyType[64];
	char	DRMFile[256];
}DBSTAR_PRODUCT_S;

typedef struct{
	char	type[64];
	char	uri[256];
}COLUMNICON_S;

typedef struct{
	char	ServiceID[64];
	char	ColumnID[64];
	char	ParentID[64];
	char	Path[256];
	char	ColumnType[256];
	char	ColumnIcon_losefocus[256];
	char	ColumnIcon_getfocus[256];
	char	ColumnIcon_onclick[256];
}DBSTAR_COLUMN_S;

typedef struct{
	char	ServiceID[64];
	char	DateValue[64];
	char	GuideListID[64];
	char	productID[64];
	char	PublicationID[64];
}DBSTAR_GUIDELIST_S;

typedef struct{
	char	ServiceID[64];
	char	ReceiveType[64];
	char	rootPath[256];
	char	ProductDescID[128];
	char	productID[64];
	char	SetID[64];
	char	ID[64];
	char	TotalSize[64];
	char	URI[256];
	char	DescURI[384];
	char	PushStartTime[64];
	char	PushEndTime[64];
	char	Columns[512];	// it's better to use malloc and relloc
	char	ReceiveStatus[32];
	char	version[64];
}DBSTAR_PRODUCTDESC_S;

typedef struct{
	char	ServiceID[64];
	char	SetID[64];
	char	PublicationType[64];
	char	IsReserved[64];
	char	Visible[64];
	char	Title[128];
	char	Starring[1024];
	char	Scenario[8192];
	char	Classification[64];
	char	Period[64];
	char	CollectionNumber[64];
	char	Review[64];
}DBSTAR_PUBLICATIONSSET_S;

typedef struct{
	char	serviceID[64];
	char	navigationType[64];
}DBSTAR_NAVIGATION_S;

typedef struct{
	char	ServiceID[64];
	char	columnID[64];
	char	EntityID[64];
}DBSTAR_COLUMNENTITY_S;

typedef struct{
	char	ServiceID[64];
	char	PublicationID[64];
	char	PublicationType[64];
	char	IsReserved[32];
	char	Visible[32];
	char	DRMFile[256];
	char	FileID[64];
	char	FileSize[64];
	char	FileURI[256];
	char	FileType[64];
	char	Duration[32];
	char	Resolution[32];
	char	BitRate[32];
	char	FileFormat[32];
	char	CodeFormat[32];
}DBSTAR_PUBLICATION_S;

/*
 ��ԱPublicationType��IsReserved��Visibleֻ��Ϊ�˽��ṹ��Publication�е���Ϣ͸����PublicationsSet
*/
typedef struct{
	char	ServiceID[64];
	char	PublicationID[64];
	char	infolang[64];
	char	PublicationDesc[8192];
	char	Keywords[1024];
	char	ImageDefinition[32];
	char	Area[512];
	char	Language[64];
	char	Episode[32];
	char	AspectRatio[32];
	char	AudioChannel[32];
	char	Director[512];
	char	Actor[1024];
	char	Audience[512];
	char	Model[32];
}DBSTAR_MULTIPLELANGUAGEINFOVA_S;

typedef struct{
	char	ServiceID[64];
	char	PublicationID[64];
	char	infolang[64];
	char	*PublicationDesc;
	char	Keywords[256];
	char	Publisher[128];
	char	Area[64];
	char	Language[64];
	char	Episode[64];
	char	AspectRatio[64];
	char	VolNum[64];
	char	ISSN[64];
}DBSTAR_MULTIPLELANGUAGEINFORM_S;

typedef struct{
	char	ServiceID[64];
	char	PublicationID[64];
	char	infolang[64];
	char	*PublicationDesc;
	char	Keywords[256];
	char	Category[64];
	char	Released[64];
	char	AppVersion[64];
	char	Language[64];
	char	Developer[64];
	char	Rated[64];
}DBSTAR_MULTIPLELANGUAGEINFOAPP_S;


typedef struct{
	char	ServiceID[64];
	char	MessageID[64];
	char	type[64];
	char	displayForm[64];
	char	StartTime[64];
	char	EndTime[64];
	char	Interval[64];
}DBSTAR_MESSAGE_S;

typedef struct{
	char	ServiceID[64];
	char	PublicationID[64];
	char	PreviewID[64];
	char	PreviewType[64];
	char	PreviewSize[64];
	char	ShowTime[64];
	char	PreviewURI[256];
	char	PreviewFormat[64];
	char	Duration[64];
	char	Resolution[64];
	char	BitRate[64];
	char	CodeFormat[64];
}DBSTAR_PREVIEW_S;


typedef struct{
	char	ServiceID[64];
	char	SType[64];
	char	Name[64];
	char	URI[256];
}DBSTAR_SPRODUCT_S;



typedef enum{
	DBSTAR_CMD_OP_UNDEFINED = 0,
	DBSTAR_CMD_OP_DELETE = 1,
	DBSTAR_CMD_OP_UPDATE = 2,
	DBSTAR_CMD_OP_CANCELRESERVATION = 3,
	DBSTAR_CMD_OP_RESERVE = 4,
	DBSTAR_CMD_OP_FORCEDISPLAY = 5,
	DBSTAR_CMD_OP_FORCEHIDE = 6
}DBSTAR_CMD_OP_TYPE_E;

typedef enum{
	DBSTAR_CMD_OBJ_UNDEFINED = 0,
	DBSTAR_CMD_OBJ_PUBLICATION = 1,
	DBSTAR_CMD_OBJ_PRODUCT = 2,
	DBSTAR_CMD_OBJ_PREVIEW = 3
}DBSTAR_CMD_OBJ_TYPE_E;

typedef enum{
	DBSTAR_CMD_OBJ_FILE_UNDEFINED = 0,
	DBSTAR_CMD_OBJ_FILE_DESCRIPTION = 1,
	DBSTAR_CMD_OBJ_FILE_SUBTITLE = 2,
	DBSTAR_CMD_OBJ_FILE_POSTER = 3
}DBSTAR_CMD_OBJ_FILE_TYPE_E;

typedef struct{
	char						ID[64];
	DBSTAR_CMD_OBJ_FILE_TYPE_E	fileType;
}DBSTAR_CMD_OBJ_S;

typedef struct{
	DBSTAR_CMD_OP_TYPE_E	type;
	DBSTAR_CMD_OBJ_TYPE_E	objectType;
	DBSTAR_CMD_OBJ_S		object;			
}DBSTAR_CMD_OPERATION_S;


////////////////////////////////////////////////////////////////////////////////
// for dmx
#define FILTER_BUF_SIZE (4096+184)

#ifdef TUNER_INPUT
	#define MAX_CHAN_FILTER 32
	#define DMX_FILTER_SIZE 16
#else
	#define MAX_CHAN_FILTER 16
	#define DMX_FILTER_SIZE 8  //16
#endif

typedef void (*dataCb) (int fid, const unsigned char *data, int len, void *user_data);

#define HIGH_PRIORITY_FILTER_NUM 2

typedef enum {
        CHAN_STAGE_START,
        CHAN_STAGE_HEADER,
        CHAN_STAGE_PTS,
        CHAN_STAGE_PTR,
        CHAN_STAGE_DATA_SEC,
        CHAN_STAGE_DATA_PES,
        CHAN_STAGE_END
} ChannelStage_t;


typedef struct LoaderInfo LoaderInfo_t;
struct LoaderInfo {
    unsigned int stb_id_h;  //64bit
    unsigned int stb_id_l;
    unsigned char software_version[4]; //32bit
    unsigned char hardware_version[4]; //32bit
    unsigned int img_len;          //32bit
    int fid;                       //32bit
    unsigned short oui;            //16bit
    unsigned short model_type;     //16bit
    unsigned short user_group_id;  //16bit
    unsigned char  download_type;  //8bit
    unsigned char  file_type;      //8bit
	char guodian_serialnum[24];
};

/*
������صĶ���
*/
#define UPGRADEFILE_ALL "/tmp/upgrade.zip"
#define UPGRADEFILE_IMG "/cache/recovery/upgrade.zip"
#define COMMAND_FILE  "/cache/recovery/command0"
#define LOADER_PACKAGE_SIZE		(4084)

#define UPGRADE_PARA_STRUCT "/cache/recovery/last_install"
#define TC_OUI 3
#define TC_MODEL_TYPE 1
#define TC_HARDWARE_VERSION0 0
#define TC_HARDWARE_VERSION1 0
#define TC_HARDWARE_VERSION2 3
#define TC_HARDWARE_VERSION3 1
 
typedef struct Channel Channel_t;
struct Channel {
        int              bytes;
        int              fid;
        int              offset;
        int              sec_len;
        void             *userdata;
        dataCb           hdle;
        unsigned short   pid;
        unsigned char    buf[FILTER_BUF_SIZE];
        unsigned char    used;
        unsigned char    value[DMX_FILTER_SIZE+2];
        unsigned char    maskandmode[DMX_FILTER_SIZE+2];
        unsigned char    maskandnotmode[DMX_FILTER_SIZE+2];
        unsigned char    neq;
        ChannelStage_t   stage;
        unsigned char    samepidnum;
};

struct Filterp {
        unsigned char filter[DMX_FILTER_SIZE];
        unsigned char mask[DMX_FILTER_SIZE];
        unsigned char mode[DMX_FILTER_SIZE];
};
typedef struct Filterp Filter_param;
////////////////////////////////////////////////////////////////////////////////


int appoint_str2int(char *str, unsigned int str_len, unsigned int start_position, unsigned int appoint_len, int base);
unsigned int randint();
int dir_exist_ensure(char *dir);

void print_timestamp(int show_s_ms, int show_str);
int dir_ensure(char *dir);
int phony_div(unsigned int div_father, unsigned int div_son);
void ms_sleep(unsigned int ms);
char *strrstr_s(const char *str_dad, char *str_son, char signchr);
char *time_serial();
int ipv4_simple_check(const char *ip_addr);
int distill_file(char *path, char *file, unsigned int file_size, char *filefmt, char *preferential_file);
int strtailcmp(const char *str_dad, char *str_tail, int case_cmp);
int igmp_simple_check(const char *igmp_addr, char *igmp_ip, int *igmp_port);
int signed_char_clear(char *str_dad, unsigned int str_dad_len, char sign_c, int flag);
int fcopy_c(char *from_file, char *to_file);
int remove_force(const char *uri);
long long dir_size(const char *uri);
int dir_stat_ensure(const char *uri);
int disk_usable_check(char *disk_dir, unsigned long long *tt_size, unsigned long long *free_size);

#endif

