﻿#ifndef __TIMEPRINT_H__
#define __TIMEPRINT_H__

static void compile_timeprint()
{
	DEBUG("build at %s %s\n", __DATE__, __TIME__);
	return;
}

#endif