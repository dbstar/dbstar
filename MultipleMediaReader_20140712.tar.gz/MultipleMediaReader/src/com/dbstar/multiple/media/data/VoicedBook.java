package com.dbstar.multiple.media.data;

import java.util.ArrayList;
import java.util.List;

public class VoicedBook {
    public String BookId;
    public String RootPath;
    public String NcxFilePath;
    public List<VoiceBookPageInfo> mPages;
}
