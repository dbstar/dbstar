package com.dbstar.multiple.media.shelf.share;

public class ServiceApi {
    
    public static final String ACTION_DOWNLOAD_BOOK_LIST = "download/book/list";
    public static final String ACTION_DOWNLOAD_NEWSPAPER_LIST = "download/newspaper/list";
    public static final String ACTION_LOAD_ITEM = "load/item";
}
