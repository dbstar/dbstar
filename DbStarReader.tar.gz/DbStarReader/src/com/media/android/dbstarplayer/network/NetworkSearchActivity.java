/*
 * Copyright (C) 2010-2013 Geometer Plus <contact@geometerplus.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301, USA.
 */

package com.media.android.dbstarplayer.network;

import android.app.Activity;
import android.app.SearchManager;
import android.os.Bundle;
import android.content.Intent;

import com.media.zlibrary.core.util.MimeType;

import com.media.dbstarplayer.network.NetworkLibrary;
import com.media.dbstarplayer.network.NetworkTree;
import com.media.dbstarplayer.network.tree.SearchCatalogTree;

public class NetworkSearchActivity extends Activity {
	@Override
	public void onCreate(Bundle icicle) {
		super.onCreate(icicle);

		Thread.setDefaultUncaughtExceptionHandler(new com.media.zlibrary.ui.android.library.UncaughtExceptionHandler(this));

		final Intent intent = getIntent();
		if (Intent.ACTION_SEARCH.equals(intent.getAction())) {
			final Bundle data = intent.getBundleExtra(SearchManager.APP_DATA);
			if (data != null) {
				final NetworkLibrary library = NetworkLibrary.Instance();
				final NetworkTree.Key key =
					(NetworkTree.Key)data.getSerializable(NetworkLibraryActivity.TREE_KEY_KEY);
				final NetworkTree tree = library.getTreeByKey(key);
				if (tree instanceof SearchCatalogTree) {
					final SearchCatalogTree searchTree = (SearchCatalogTree)tree;
					final String pattern = intent.getStringExtra(SearchManager.QUERY);
					final MimeType mime = searchTree.getMimeType();
					if (MimeType.APP_ATOM_XML.weakEquals(mime)) {
						searchTree.startItemsLoader(pattern);
					} else if (MimeType.TEXT_HTML.weakEquals(mime)) {
						Util.openInBrowser(this, searchTree.getUrl(pattern));
					}
				}
			}
		}
		finish();
	}
}
