package com.dbstar.multiple.media.shelf.activity;

import android.app.Activity;

public class MagazineBaseActivity extends Activity {
	public void SetData(Object object) {
	}
}
