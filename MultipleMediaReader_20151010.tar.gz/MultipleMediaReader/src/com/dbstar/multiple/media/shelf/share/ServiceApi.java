package com.dbstar.multiple.media.shelf.share;

public class ServiceApi {
    
	public static final String WEB_ROOT = "/storage/external_storage/sda1/webserver/";
    public static final String ACTION_DOWNLOAD_BOOK_LIST = "ts.html";
    public static final String ACTION_DOWNLOAD_NEWSPAPER_LIST = "bz.html";
    public static final String ACTION_DOWNLOAD_MAGAZINE_LIST = "qk.html";
    public static final String ACTION_LOAD_ITEM = "load/item";
}
