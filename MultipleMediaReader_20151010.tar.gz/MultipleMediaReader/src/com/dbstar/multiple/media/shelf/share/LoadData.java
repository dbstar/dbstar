package com.dbstar.multiple.media.shelf.share;

public class LoadData {
    
	public String Id;
    public String Name;
    public String Size;
    public String Date;
    public String FilePath;
    public String Cover;
    public String Author;
}
