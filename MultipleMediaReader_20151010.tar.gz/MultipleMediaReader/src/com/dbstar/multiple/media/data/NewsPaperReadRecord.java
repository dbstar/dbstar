package com.dbstar.multiple.media.data;

public class NewsPaperReadRecord {
    
    public String NewsPaperId;
    public String Pages;
    public String Articles;
    public String PublishTime;
}
