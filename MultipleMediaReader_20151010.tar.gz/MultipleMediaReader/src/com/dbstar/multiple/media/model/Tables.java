package com.dbstar.multiple.media.model;


public interface Tables {
    
    String VOICEDBOOK = ModelVoicedBook.VOICEDBOOK_TABLE_NAME;
    
    
}
